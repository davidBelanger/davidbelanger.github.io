These are the exact data files used in our ICML experiments. The original data can be found at http://mulan.sourceforge.net/datasets.html.

Use ./data-shuffle for tuning parameters and ./data for testing. For the bookmarks dataset, there was a proper train-dev-test split, so you should use the data in ./data for both tuning and evaluation for bookmarks.

